<?php

session_start();

include("DBconfig.php");
$query = "SELECT * FROM location WHERE loc_id = " . $_COOKIE['loc_id'];
$result = $conn->query($query);
$location = '';
foreach ($result as $loc) {
    $location = $loc['location'];
}

$query = "SELECT * FROM cars WHERE car_id = " . $_COOKIE['car_id'];
$result = $conn->query($query);
$car_name = '';
foreach ($result as $loc) {
    $car_name = $loc['car_name'];
}

$car_model = $_COOKIE['car_model'];

$user_id = $_SESSION['user_id'];

$quote = serialize($_SESSION['cart']);

$total = $_SESSION['TotalPrice'];

$query1 = "INSERT INTO `requests`(`user_id`, `qoute`, `total`, `car_name`, `model`, `location`)
    VALUES (
        $user_id,
        '$quote',
        '$total',
        '$car_name',
        '$car_model',
        '$location'
    )";

$conn->query($query1);
$_SESSION['status'] = 'Pending';

$_SESSION['user_req_id'] = mysqli_insert_id($conn);

header("Location: status.php");

?>