<style>
    
 footer{
        margin: 0;
        padding: 60px;
        height: 450px;
        background-color: #394a6d;
    }
footer .row{
    height: 90%;
    width: 100%;
    margin-left:90px;
}
footer .col-lg-6{
    color: white;
    
}
footer .col-lg-6:first-child{
        border-right: 1px solid white;
    }
footer h3{
        margin-top: 0px;
        margin-bottom: 40px;
    }
    
footer .col-lg-6 p{
        margin-top: 30px;
    }
    
.foot{
        margin-top: -245px;
        margin-left: 500px;
        font-weight: bold;
    }
</style>
<footer>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-6" >
                    <h3>Our Services</h3>
                    <h4>Dent</h4>
                    <h4>Battery Service</h4>
                     <h4>Car Inspection</h4>
                     <h4>painting</h4>
                     <h4>Car Services</h4>
                </div>

                <div class="col-lg-6 foot">
                             <p onclick="window.location.href='index.html' ">Home</p>
                             <p onclick="window.location.href='' ">Sign up</p>
                             <p onclick="window.location.href='index.html' ">Login</p>
                             <p onclick="window.location.href='index.html' ">Contact Us</p>
                             <p onclick="window.location.href='index.html' ">About us</p>
                </div>
            </div>
        </div>

        <div>
            <p style="color: white;">@2019 MyMechanic</p>        
        </div>

    </section>
</footer>